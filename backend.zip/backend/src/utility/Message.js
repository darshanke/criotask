const TASK_NOT_CREATED = "Task not created";
const TASK_ALREADY_EXIST = "Task Already Exist";


module.exports = {TASK_NOT_CREATED, TASK_ALREADY_EXIST}