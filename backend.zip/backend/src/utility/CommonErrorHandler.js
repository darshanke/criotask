const commonErrorHandler=(message)=>{
    return {
        message: message
    }
}

module.exports = {
    commonErrorHandler
}